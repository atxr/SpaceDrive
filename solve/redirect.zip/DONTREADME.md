# mineziper 💣
### A Minevesdrladsdsfiles.ds
Detect dd bdsvesdlaswebsd on oeper for zip files!
avesdlaswe
Detect zivesdlaswesdsp vesdlaswebombs baseddovesdlaswevesdrladsdsfiles.ds
Detect dd bdsbvesdlaswesd on ovesdladng filesd.
dvesdlaswevesdlaswevesdlaswedlasvesdlaswewe